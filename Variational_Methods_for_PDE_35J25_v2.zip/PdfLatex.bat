@echo off
setlocal enabledelayedexpansion

echo ========================================
echo   Compiling Main Document with BibTeX
echo ========================================
echo.

set TEXLIVE_PATH=E:\Processings\Doctorate\texlive\2024\bin\windows\
set SUMATRA_EXE=SumatraPDF.exe

echo Searching for .tex file in current directory...
for %%f in (*.tex) do (
    set FILENAME=%%~nf
    set FULLTEX=%%f
    echo Found: !FILENAME!.tex
    goto :found
)
echo ERROR: No .tex file found in current directory!
pause
goto :end

:found
echo.

echo ========================================
echo   STEP 0: Killing PDF viewers only
echo ========================================
echo Closing PDF viewers before compilation...
taskkill /f /im Acrobat.exe 2>nul
taskkill /f /im AcroRd32.exe 2>nul
taskkill /f /im AcrobatReader.exe 2>nul
taskkill /f /im AcroCEF.exe 2>nul
taskkill /f /im FoxitReader.exe 2>nul
taskkill /f /im FoxitPDFReader.exe 2>nul
timeout /t 1 /nobreak >nul
del /f /q "indexstyle.ist" 2>nul
del /f /q "references.bib" 2>nul
echo Done.
echo.

echo ========================================
echo   Cleaning old files...
echo ========================================
if exist "!FILENAME!.pdf" (
    echo Deleting !FILENAME!.pdf...
    attrib -r "!FILENAME!.pdf" 2>nul
    del /f /q "!FILENAME!.pdf" 2>nul
)
del /f /q "!FILENAME!.aux" "!FILENAME!.bbl" "!FILENAME!.bcf" "!FILENAME!.blg" 2>nul
del /f /q "!FILENAME!.idx" "!FILENAME!.ilg" "!FILENAME!.ind" 2>nul
del /f /q "!FILENAME!.log" "!FILENAME!.out" "!FILENAME!.toc" 2>nul
del /f /q "!FILENAME!.bbl" 2>nul
del /f /q "!FILENAME!.synctex.gz" 2>nul
del /f /q "!FILENAME!.run.xml" 2>nul
:: Delete indexstyle.ist and references.bib
del /f /q "indexstyle.ist" 2>nul
del /f /q "references.bib" 2>nul
echo Done.
echo.

echo ========================================
echo   STEP 1: pdflatex (first pass)
echo ========================================
"%TEXLIVE_PATH%pdflatex.exe" -interaction=nonstopmode "!FULLTEX!"
if errorlevel 1 (
    echo ERROR: First pdflatex pass failed!
    goto error
)
echo.

echo ========================================
echo   STEP 2: bibtex
echo ========================================
if exist "!FILENAME!.aux" (
    "%TEXLIVE_PATH%bibtex.exe" "!FILENAME!"
    if errorlevel 1 (
        echo WARNING: BibTeX had issues - check references.bib
    )
) else (
    echo WARNING: !FILENAME!.aux not found - BibTeX skipped
)
echo.

echo ========================================
echo   STEP 3: makeindex
echo ========================================
if exist "!FILENAME!.idx" (
    if exist "indexstyle.ist" (
        "%TEXLIVE_PATH%makeindex.exe" -s indexstyle.ist "!FILENAME!.idx"
        if errorlevel 1 (
            echo WARNING: makeindex had issues
        )
    ) else (
        echo WARNING: indexstyle.ist not found - running makeindex without style
        "%TEXLIVE_PATH%makeindex.exe" "!FILENAME!.idx"
    )
) else (
    echo No index file found - skipping makeindex
)
echo.

echo ========================================
echo   STEP 4: pdflatex (second pass)
echo ========================================
"%TEXLIVE_PATH%pdflatex.exe" -interaction=nonstopmode "!FULLTEX!"
if errorlevel 1 (
    echo ERROR: Second pdflatex pass failed!
    goto error
)
echo.

echo ========================================
echo   STEP 5: pdflatex (final pass)
echo ========================================
"%TEXLIVE_PATH%pdflatex.exe" -interaction=nonstopmode "!FULLTEX!"
if errorlevel 1 (
    echo ERROR: Final pdflatex pass failed!
    goto error
)
echo.

if exist "!FILENAME!.pdf" (
    echo ========================================
    echo   SUCCESS! PDF created
    echo ========================================
    echo.
    echo Output: !FILENAME!.pdf
    echo.
    
    echo ========================================
    echo   Opening with SumatraPDF only
    echo ========================================
    
    echo Closing any remaining PDF viewers...
    taskkill /f /im Acrobat.exe 2>nul
    taskkill /f /im AcroRd32.exe 2>nul
    taskkill /f /im AcrobatReader.exe 2>nul
    taskkill /f /im FoxitReader.exe 2>nul
    taskkill /f /im SumatraPDF.exe 2>nul
    timeout /t 1 /nobreak >nul
    
    if exist "%CD%\%SUMATRA_EXE%" (
        echo Found SumatraPDF in current directory.
        echo.
        echo Opening PDF with SumatraPDF...
        start "" "%CD%\%SUMATRA_EXE%" -reuse-instance "!FILENAME!.pdf"
        echo.
        echo ========================================
        echo   SumatraPDF opened successfully!
        echo   PDF: %CD%\!FILENAME!.pdf
        echo ========================================
    ) else (
        echo ========================================
        echo   ERROR: SumatraPDF not found!
        echo ========================================
        echo.
        echo Expected location: %CD%\%SUMATRA_EXE%
        echo.
        echo Please ensure SumatraPDF.exe is in the same directory
        echo as this batch file.
        echo.
        echo Download from: https://www.sumatrapdfreader.org/download.html
        echo.
        echo PDF created at: %CD%\!FILENAME!.pdf
        echo.
    )
) else (
    echo ========================================
    echo   ERROR: PDF not created
    echo ========================================
    echo.
    echo Check !FILENAME!.log for errors
    pause
    goto end
)

goto end

:error
echo.
echo ========================================
echo   ERROR: Compilation failed
echo ========================================
echo.
echo Check the following files for errors:
echo   - !FILENAME!.log
echo   - !FILENAME!.aux
echo   - references.bib
echo.
pause

:end
pause