import sympy as sp
import numpy as np
import matplotlib.pyplot as plt

# Define the variable
x = sp.symbols('x')

# =========================
# Input function
# =========================
def input_function():
    try:
        f_str = input("Enter the function f(x): ")
        f = sp.sympify(f_str)
        return f
    except Exception as e:
        print("Error in function input:", e)
        return None

# =========================
# Domain of function
# =========================
def domain_of_function(f):
    domain = sp.calculus.util.continuous_domain(f, x, sp.S.Reals)
    print("Domain:", domain)
    return domain

# =========================
# Derivative and critical points
# =========================
def derivative_and_critical_points(f):
    f_prime = sp.diff(f, x)
    critical_points = sp.solveset(f_prime, x, sp.S.Reals)
    print("First derivative:", f_prime)
    print("Critical points:", list(critical_points))
    return f_prime, critical_points

# =========================
# Increasing/decreasing
# =========================
def increasing_decreasing(f_prime, critical_points):
    print("Increasing/decreasing analysis:")
    
    # Keep only real critical points and sort them
    critical_points = sorted([p for p in critical_points if p.is_real])
    boundaries = [-sp.oo] + critical_points + [sp.oo]
    
    # Build intervals between boundaries
    for i in range(len(boundaries) - 1):
        a, b = boundaries[i], boundaries[i+1]
        interval = sp.Interval.open(a, b)
        
        # Choose a test point in the interval
        if a is -sp.oo and b is sp.oo:
            test_point = 0  # whole real line, pick 0
        elif a is -sp.oo:
            test_point = b - 1
        elif b is sp.oo:
            test_point = a + 1
        else:
            test_point = (a + b) / 2  # midpoint
        
        # Evaluate sign of derivative
        sign = sp.sign(f_prime.subs(x, test_point))
        if sign > 0:
            print(f"Function is increasing on {interval}")
        elif sign < 0:
            print(f"Function is decreasing on {interval}")
        else:
            print(f"Function is constant on {interval}")



# =========================
# Local extrema
# =========================
def local_extrema(f, f_prime, critical_points):
    f_second = sp.diff(f_prime, x)
    print("Local extrema:")
    for p in critical_points:
        test = f_second.subs(x, p)
        y_val = f.subs(x, p)
        if test > 0:
            print(f"Local minimum at x = {p}, y = {y_val}")
        elif test < 0:
            print(f"Local maximum at x = {p}, y = {y_val}")
        else:
            print(f"Inconclusive at x = {p}, possible inflection point")

# =========================
# Plot function
# =========================
def plot_function(f):
    f_num = sp.lambdify(x, f, 'numpy')
    try:
        X = np.linspace(-10, 10, 400)
        Y = f_num(X)
    except Exception as e:
        print("Error in plotting:", e)
        return
    
    plt.figure(figsize=(8, 6))
    plt.plot(X, Y, 'b-', linewidth=2)
    plt.axhline(y=0, color='k', linestyle='-', alpha=0.3)
    plt.axvline(x=0, color='k', linestyle='-', alpha=0.3)
    plt.grid(True)
    plt.xlabel('x')
    plt.ylabel('f(x)')
    plt.title('Function Graph')
    plt.show()

# =========================
# Main program
# =========================
def main():
    print("Function Analysis Tool")
    f = input_function()
    if f is None:
        return
    
    while True:
        print("\nSelect:")
        print("1 - Domain")
        print("2 - Derivative and critical points")
        print("3 - Increasing/decreasing")
        print("4 - Local extrema")
        print("5 - Plot")
        print("0 - Exit")
        
        choice = input("Your choice: ")
        
        if choice == "1":
            domain_of_function(f)
        
        elif choice == "2":
            f_prime, critical_points = derivative_and_critical_points(f)
        
        elif choice == "3":
            f_prime, critical_points = derivative_and_critical_points(f)
            increasing_decreasing(f_prime, critical_points)
        
        elif choice == "4":
            f_prime, critical_points = derivative_and_critical_points(f)
            local_extrema(f, f_prime, critical_points)
        
        elif choice == "5":
            plot_function(f)
        
        elif choice == "0":
            print("Goodbye")
            break
        
        else:
            print("Invalid choice")

# Run only if executed directly
if __name__ == "__main__":
    main()
