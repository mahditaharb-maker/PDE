@echo off
REM Build script for LaTeX thesis on Windows
REM Usage: double-click build.bat or run in Command Prompt

REM Add TeX Live compiler directory to PATH
set PATH=E:\archives\25\Doctorate\texlive\2024\bin\windows;%PATH%

set MAIN=4
cd /d D:\1

echo === LaTeX Thesis Build Started ===

pdflatex "%MAIN%.tex"
bibtex "%MAIN%"
makeglossaries "%MAIN%"
makeindex "%MAIN%"
pdflatex "%MAIN%.tex"
pdflatex "%MAIN%.tex"


echo === Cleaning auxiliary files ===
del /Q D:\1\*.aux D:\1\*.bbl D:\1\*.blg D:\1\*.log D:\1\*.toc D:\1\*.lof D:\1\*.lot D:\1\*.out D:\1\*.acr D:\1\*.gls D:\1\*.glo D:\1\*.ist D:\1\*.xdy

echo === Cleaning LaTeX auxiliary files in D:\1 ===


del /Q D:\1\*.acn
del /Q D:\1\*.alg
del /Q D:\1\*.glg
del /Q D:\1\*.idx
del /Q D:\1\*.ind
del /Q D:\1\*.ilg
del /Q D:\1\*.sbl
del /Q D:\1\*.slg
del /Q D:\1\*.sym



echo === Cleanup Complete ===

echo === Build Complete ===
echo Output: %MAIN%.pdf
pause
