@echo off
REM Build script for LaTeX thesis on Windows
REM Usage: double-click build.bat or run in Command Prompt

REM Add TeX Live compiler directory to PATH
set PATH=E:\archives\25\Doctorate\texlive\2024\bin\windows;%PATH%

set MAIN=2
cd /d D:\1

echo === LaTeX Thesis Build Started ===

REM First LaTeX run
pdflatex "%MAIN%.tex"

REM Run BibTeX
bibtex "%MAIN%"

REM Run MakeGlossaries
makeglossaries "%MAIN%"

REM Second LaTeX run
pdflatex "%MAIN%.tex"

REM Third LaTeX run
pdflatex "%MAIN%.tex"

echo === Cleaning auxiliary files ===
del /Q D:\1\*.aux D:\1\*.bbl D:\1\*.blg D:\1\*.log D:\1\*.toc D:\1\*.lof D:\1\*.lot D:\1\*.out D:\1\*.acr D:\1\*.gls D:\1\*.glo D:\1\*.ist D:\1\*.xdy

echo === Cleaning LaTeX auxiliary files in D:\1 ===


del /Q D:\1\*.acn
del /Q D:\1\*.alg
del /Q D:\1\*.glg


echo === Cleanup Complete ===

echo === Build Complete ===
echo Output: %MAIN%.pdf
pause
