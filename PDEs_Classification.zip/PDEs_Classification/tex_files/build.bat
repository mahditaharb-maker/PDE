@echo off
REM Build script for LaTeX thesis on Windows
REM Usage: double-click build.bat or run in Command Prompt

set MAIN=Full_Thesis_LaTeX_Skeleton

echo === LaTeX Thesis Build Started ===

REM First LaTeX run
pdflatex %MAIN%.tex

REM Run BibTeX
bibtex %MAIN%

REM Run MakeGlossaries
makeglossaries %MAIN%

REM Second LaTeX run
pdflatex %MAIN%.tex

REM Third LaTeX run
pdflatex %MAIN%.tex

echo === Build Complete ===
echo Output: %MAIN%.pdf
pause
