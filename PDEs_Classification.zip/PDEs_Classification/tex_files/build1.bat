@echo off
set PATH=E:\archives\25\Doctorate\texlive\2024\bin\windows;%PATH%

set MAIN=2
cd /d D:\1

echo === LaTeX Thesis Build Started ===

pdflatex "%MAIN%.tex"
bibtex "%MAIN%"
makeglossaries "%MAIN%"
pdflatex "%MAIN%.tex"
pdflatex "%MAIN%.tex"

echo === Build Finished ===
pause
